@extends('template.master')
@section('content')
<main id="main">
    <section id="about-us" class="about-us mt-5">
        <div class="container" data-aos="fade-up">
    
          <div class="row content">
            <div class="col-8" data-aos="fade-right mb-3">
              <h5>Persyaratan IPPT</h5>
              <h6 class="text-warning">Biaya : Rp. 50.000</h6>
              @if ($active->aktif)
              <h6 class="text-success"> Estimasi Waktu 5 Hari Kerja*</h6>
              @endif              
            </div>
            <div class="col-4" data-aos="fade-right mb-3">
                <a href="{{ route('Persyaratan') }}" class="float-right mt-2"><i class="ri-arrow-left-circle-line" style="color: #29cc61;"></i> Kembali</a>
                <a href="{{ route('IpptPdf') }}" class="btn btn-sm btn-success btn-rounded float-right mt-3">Download</a>
            </div>
            @if ($active->aktif)
            <div class="col-12">
              <small class="text-success">Jika berkas persyaratan pemohon lengkap</small>  
            </div>       
            @endif   

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              <p><b><u>Izin Perubahan Penggunaan Tanah (IPPT)</u></b></p>
              <ul>
                <li><i class="ri-check-double-line"></i> Sertipikat Asli</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Pemilik Sertipikat</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermatrai Asli (Jika Dikuasakan)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Kuasa</li>
              </ul>
              {{-- <p class="fst-italic">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                magna aliqua.
              </p> --}}
            </div>

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              <p><b><u>Pencatatan Izin Perubahan Penggunaan Tanah (IPPT)</u></b></p>
              <ul>
                <li><i class="ri-check-double-line"></i> Sertipikat Asli</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Pemilik Sertipikat</li>
                <li><i class="ri-check-double-line"></i> FC Pertek</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermatrai Asli (Jika Dikuasakan)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Kuasa</li>
              </ul>
            </div>

            

          </div>
    
        </div>
      </section><!-- End About Us Section -->
</main>

@endsection
@section('script')
    
@endsection
<!-- ======= About Us Section ======= -->
