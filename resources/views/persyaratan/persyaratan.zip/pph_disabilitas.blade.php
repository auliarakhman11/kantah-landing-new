@extends('template.master')
@section('content')
<main id="main">
    <section id="about-us" class="about-us mt-5">
        <div class="container" data-aos="fade-up">
    
          <div class="row content">
            <div class="col-8" data-aos="fade-right mb-3">
              <h5>Persyaratan Peralihan Hak (Disabilitas)</h5>
            </div>
            <div class="col-4" data-aos="fade-right mb-3">
                <a href="{{ route('Persyaratan') }}" class="float-right"><i class="ri-arrow-left-circle-line" style="color: #29cc61;"></i> Kembali</a>
            </div>

            <div class="col-7"></div>
            <div class="col-5" data-aos="fade-right mb-3"><a href="{{ route('PphDisabilitasPdf') }}" class="btn btn-sm btn-success btn-rounded float-right"><i class="ri-file-download-line" ></i> Download PDF</a></div>

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              <p><b><u>Peralihan Hak - Jual Beli</u></b></p>
              <ul>
                <li><i class="ri-check-double-line"></i> Sertikfikat Asli</li>
                <li><i class="ri-check-double-line"></i> Akta Jual Beli (Dari Notaris)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penjual</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Pembeli</li>
                <li><i class="ri-check-double-line"></i> SPPT PBB Tahun Berjalan</li>
                <li><i class="ri-check-double-line"></i> BPHTB</li>
                <li><i class="ri-check-double-line"></i> SSP(Surat Setoran Pajak)</li>
                <li><i class="ri-check-double-line"></i> Kartu Jaminan Kesehatan Nasional (JKN)</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermatrai Asli (Jika Dikuasakan)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Kuasa</li>
              </ul>
              {{-- <p class="fst-italic">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                magna aliqua.
              </p> --}}
            </div>

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              <p><b><u>Peralihan Hak - Waris</u></b></p>
              <ul>
                <li><i class="ri-check-double-line"></i> Sertikfikat Asli</li>
                <li><i class="ri-check-double-line"></i> Surat Kematian 1 Lembar Asli & FC</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Seluruh Ahli Waris 1 Lembar</li>
                <li><i class="ri-check-double-line"></i> Surat Pernyataan Waris 1 Lembar Asli & FC Di Leges Kelurahan</li>
                <li><i class="ri-check-double-line"></i> Surat Keterangan Waris Dari Desa 1 Lembar Asli & FC Di Leges Kelurahan</li>
                <li><i class="ri-check-double-line"></i> SPPT PBB Tahun Berjalan</li>
                <li><i class="ri-check-double-line"></i> BPHTB</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermatrai Asli (Jika Dikuasakan)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Kuasa</li>
                
              </ul>
            </div>


            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              <p><b><u>Peralihan Hak - Hibah</u></b></p>
              <ul>
                <li><i class="ri-check-double-line"></i> Sertikfikat Asli</li>
                <li><i class="ri-check-double-line"></i> Akta Hibah (Dari Notaris)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Pemberi Hibah</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Hibah</li>
                <li><i class="ri-check-double-line"></i> SPPT PBB Tahun Berjalan</li>
                <li><i class="ri-check-double-line"></i> BPHTB</li>
                <li><i class="ri-check-double-line"></i> SSP(Surat Setoran Pajak)</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermatrai Asli (Jika Dikuasakan)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Kuasa</li>
              </ul>
            </div>

          </div>
    
        </div>
      </section><!-- End About Us Section -->
</main>

@endsection
@section('script')
    
@endsection
<!-- ======= About Us Section ======= -->
