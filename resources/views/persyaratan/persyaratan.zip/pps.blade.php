@extends('template.master')
@section('content')
<main id="main">
    <section id="about-us" class="about-us mt-5">
        <div class="container" data-aos="fade-up">
    
          <div class="row content">
            <div class="col-8" data-aos="fade-right mb-3">
              <h5>Persyaratan Permohonan Sertifikat</h5>
              @if ($active->aktif)
              <h6 class="text-success">Estimasi Waktu 97 Hari Kerja*</h6>
              @endif
            </div>
            <div class="col-4" data-aos="fade-right mb-3">
                <a href="{{ route('Persyaratan') }}" class="float-right mt-2"><i class="ri-arrow-left-circle-line" style="color: #29cc61;"></i> Kembali</a>
                <a href="{{ route('ppsPdf') }}" class="btn btn-sm btn-success btn-rounded float-right mt-3">Download</a>
            </div>
          
            @if ($active->aktif)
            <div class="col-12">
              <small class="text-success">Jika berkas persyaratan pemohon lengkap</small>  
            </div>
            @endif

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              {{-- <p><b><u>Pencatatan Pelunasan BPHTB/PPH</u></b></p> --}}
              <ul>
                <li><i class="ri-check-double-line"></i> Foto copy KTP & KK Sesuai Alas Hak 2 Lbr (Memperlihatkan Yang Asli)</li>
                <li><i class="ri-check-double-line"></i> Alas Hak (Asli & FC Yang Leges Kelurahan 1 Lbr)</li>
                <p><b>"Surat Keterangan Dari Pemohon Bahwa Tanah Tersebut Bukan Tanah Sengketa & Bukan hutang Piutang" (Asli & FC Legalisir Kelurahan 1 Lbr)</b></p>
                <li><i class="ri-check-double-line"></i> SPPFBT</li>
                <li><i class="ri-check-double-line"></i> Riwayat Perolehan Tanah
                    <ul>
                        <li>A. Jual Beli : Kwitansi Asli & FC 1 Lbr</li>
                        <li>B. Waris : 
                            <ul>
                                <li>a. Surat Kematian (FC Leges Kelurahan 2 Lbr)</li>
                                <li>b. FC KTP & KK Ahli Waris</li>
                                <li>c. Surat Pernyataan Waris (Asli & FC Legalisir Kelurahan 1 Lbr)</li>
                                <li>d. Surat Keterangan Waris Oleh Desa (Asli & FC Legalisir Kelurahan 1 Lbr)</li>
                                <li>c. Surat Penyerahan Hak Waris (Asli & FC Legalisir Kelurahan 1 Lbr)</li>
                            </ul>
                        </li>
                        <li>C. Hibah : Surat Pernyataan/Keteragan Hibah (Asli & FC Legalisir Kelurahan 1 Lbr)</li>
                    </ul>
                </li>

                <li><i class="ri-check-double-line"></i> FC Alas Hak Pemilik Sebelumnya Legalisir Kelurahan 2 Lbr</li>
                <li><i class="ri-check-double-line"></i> Surat Keterangan Alas Hak Pemilik Sebelumnya Sudah Ditarik Oleh Kelurahan (Asli & FC Legalisir Kelurahan 2 Lbr)</li>
                <li><i class="ri-check-double-line"></i> Surat Keterangan "Jika Belum Pernah Dibuatkan Alas Hak" (Asli & FC Legalisir Kelurahan 1 Lbr)</li>
                <li><i class="ri-check-double-line"></i> FC NPWP "Jika Transaksi Jual Beli diatas 60 Juta" 1 Lbr</li>
                <li><i class="ri-check-double-line"></i> SPPT PBB Tahun Berjalan (Asli & FC 1 Lbr)</li>
                <li><i class="ri-check-double-line"></i> Foto lokasi Dengan Empat Sudut Terlihat Patok & Akses Jalan (Foto diprint/Cetak)</li>
                <li><i class="ri-check-double-line"></i> Foto Lokasi Dengan Aplikasi Foto Geotag (Bagikan Via Email: <br> <u><b>pendaftaran.kantahkab.banjar@gmail.com</b></u>)</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermatrai Asli</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Kuasa 2 Lbr</li>
                
                
              </ul>
              {{-- <p class="fst-italic">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                magna aliqua.
              </p> --}}
            </div>

            <div class="col-12 mt-3">
              <h5>Simulasi Biaya</h5>
            </div>

                <div class="col-4 mt-2" >
                    <label for="">Penggunaan</label>
                </div>
                <div class="col-8 mt-2">
                  <select id="jenis_tanah" class="form-control">
                    <option value="1">Pertanian</option>
                    <option value="2">Non Pertanian</option>  
                  </select>
                </div>
                <div class="col-4 mt-2" >
                    <label for="">Luas Tanah</label>                  
                </div>
                <div class="col-8 mt-2">
                  <input type="number" class="form-control form-control-sm" id="luas" value="100">
                </div>
                <div class="col-4 mt-2" ></div>
                <div class="col-8 mt-2">
                  <button type="button" class="btn btn-success btn-sm" id="lanjutkan">Lanjutkan</button>
                </div>

                <div class="col-12 mt-2" id="hasil"></div>            

          </div>
    
        </div>
      </section><!-- End About Us Section -->
</main>

@endsection
@section('script')
    <script>
      $(document).ready(function () {



        $(document).on('click', '#lanjutkan', function() {
          var luas = $('#luas').val();
          var jenis_tanah = $('#jenis_tanah').val();

          if(!luas || !jenis_tanah || luas == 0){
            var html = '<div class="alert alert-danger" role="alert"><b>Inputan tidak boleh Kosong!!!</b></div>';
            $('#hasil').html(html);
          }else{
            if(jenis_tanah == 1){
              var t_pengukuran = 100;
              var t_pemeriksaan = 20;
            }else{
              var t_pengukuran = 200;
              var t_pemeriksaan = 40;
            }
            var tarif_pengukuran = luas * t_pengukuran + 100000;
            var tarif_pemeriksaan = luas * t_pemeriksaan + 350000;
            var tarif_pendaftaran = 50000;
            var tarif = tarif_pengukuran + tarif_pemeriksaan + tarif_pendaftaran;

            var html = '<div class="alert alert-success" role="alert"><b>Estimasi Biaya : '+ tarif.toLocaleString('en-US') +'</b> <br>Teridiri dari: <br><table><tr><td>- Tarif Pengukuran</td><td>=</td><td>'+luas+' x '+t_pengukuran+' + 100,000</td></tr><tr><td>- Tarif Pemeriksaan</td><td>=</td><td>'+luas+' x '+t_pemeriksaan+' + 350,000</td></tr><tr><td>- Tarif Pendaftaran</td><td>=</td><td>'+tarif_pendaftaran.toLocaleString('en-US')+'</td></tr></table><i><u>Catatan : Biaya diatas belum termasuk biaya transportasi, akomodasi dan konsumsi yang dibebankan kepada pemohon (Pasal 21 Peraturan Pemerintah nomor 128 Tahun 2015)</u></i></div>';

            $('#hasil').html(html);
          }

        });


      });
    </script>
@endsection
<!-- ======= About Us Section ======= -->