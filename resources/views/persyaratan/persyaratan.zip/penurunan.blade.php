@extends('template.master')
@section('content')
<main id="main">
    <section id="about-us" class="about-us mt-5">
        <div class="container" data-aos="fade-up">
    
          <div class="row content">
            <div class="col-8" data-aos="fade-right mb-3">
              <h5>Persyaratan Perubahan Hak (Penurunan)</h5>
              <h5 class="text-warning">Biaya : Rp. 50.000</h5>
              
              @if ($active->aktif)
              <h6 class="text-success">Estimasi Waktu 5 Hari Kerja</h6>
              @endif
            </div>
            <div class="col-4" data-aos="fade-right mb-3">
                <a href="{{ route('Persyaratan') }}" class="float-right mt-2"><i class="ri-arrow-left-circle-line" style="color: #29cc61;"></i> Kembali</a>
                <a href="{{ route('penurunanPdf') }}" class="btn btn-sm btn-success btn-rounded float-right mt-3">Download</a>
            </div>

            @if ($active->aktif)
            <div class="col-12">
              <small class="text-success">Jika berkas persyaratan pemohon lengkap</small>  
            </div>
            @endif

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              
              <ul>
                <li><i class="ri-check-double-line"></i> Sertipikat Asli</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Pemilik Sertipikat</li>
                <li><i class="ri-check-double-line"></i> FC SPPT PBB Tahun Berjalan</li>
                <li><i class="ri-check-double-line"></i> FC Perjanjian Pengikatan Jual Beli (PPJB)</li>
                <li><i class="ri-check-double-line"></i> Surat Pernyataan Mandiri (Alasan Kenapa Diturunkan) <br> EX: Mau Dijual/Dipecah/Dipisah</li>
                <li><i class="ri-check-double-line"></i> Proposal Kegiatan</li>
                <li><i class="ri-check-double-line"></i> Identitas Badan Hukum Yang Mau Dibeli</li>
                <li><i class="ri-check-double-line"></i> NIB Berusaha</li>
                <li><i class="ri-check-double-line"></i> Akta Pendirian Dan Pengesahan Badan Hukum</li>
                <li><i class="ri-check-double-line"></i> Surat Pernyataan Usaha Mikro</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermatrai Asli (Jika Dikuasakan)</li>
                <li><i class="ri-check-double-line"></i> Perizinan Berusaha Berbasis Risiko</li>
                <li><i class="ri-check-double-line"></i> SPPL (SURAT PERNYATAAN PENGELOLAAN
                  LINGKUNGAN)</li>
                <li><i class="ri-check-double-line"></i> K3L (KESELAMATAN,KESEHATAN,KEAMANAN
                    LINGKUNGAN)</li>
                <li><i class="ri-check-double-line"></i> IZIN LOKASI/PKKPR/INFORMASI POLA RUANG</li>
                <li><i class="ri-check-double-line"></i> SURAT KUASA BERMATERAI (JIKA DIKUASAKAN)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Kuasa</li>
              </ul>
              {{-- <p class="fst-italic">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                magna aliqua.
              </p> --}}
            </div>

          </div>
    
        </div>
      </section><!-- End About Us Section -->
</main>

@endsection
@section('script')
    
@endsection
<!-- ======= About Us Section ======= -->
