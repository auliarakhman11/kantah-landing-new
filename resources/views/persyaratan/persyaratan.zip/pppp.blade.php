@extends('template.master')
@section('content')
<main id="main">
    <section id="about-us" class="about-us mt-5">
        <div class="container" data-aos="fade-up">
    
          <div class="row content">
            <div class="col-8" data-aos="fade-right mb-3">
              <h5>Persyaratan Permohonan Pemecahan, Pemisahan, Penggabungan</h5>
              @if ($active->aktif)
              <h6 class="text-success">Estimasi Waktu 15 Hari Kerja*</h6>
              @endif
            </div>
            <div class="col-4" data-aos="fade-right mb-3">
                <a href="{{ route('Persyaratan') }}" class="float-right mt-2"><i class="ri-arrow-left-circle-line" style="color: #29cc61;"></i> Kembali</a>
                <a href="{{ route('PpppPdf') }}" class="btn btn-sm btn-success btn-rounded float-right mt-3">Download</a>
            </div>
            @if ($active->aktif)
            <div class="col-12">
              <small class="text-success">Jika berkas persyaratan pemohon lengkap</small>  
            </div>
            @endif

            <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
              {{-- <p><b><u>Pencatatan Pelunasan BPHTB/PPH</u></b></p> --}}
              <ul>
                <li><i class="ri-check-double-line"></i> Sertipikat Asli</li>
                <li><i class="ri-check-double-line"></i> Asli & FC Akta Pendirian dan Pengesahan Badan Hukum</li>
                <li><i class="ri-check-double-line"></i> Gambar Rencana Pemisahan/Pemecahan</li>
                <li><i class="ri-check-double-line"></i> FC Pengesahan Siteplan dan Sitepaln Dari Pemerintah Kabupaten Atau Kota (Untuk Badan Hukum)</li>
                <li><i class="ri-check-double-line"></i> Penyelenggaraan Kebijakan Penggunaan dan Pemanfaatan Tanah (Jika Tanah Pertanian)</li>
                <li><i class="ri-check-double-line"></i> Surat Kuasa Bermeterai Asli (Jika Dikuasakan)</li>
                <li><i class="ri-check-double-line"></i> FC KTP & KK Penerima Kuasa</li>
                <li><i class="ri-check-double-line"></i> Pemecahan/Pemisahan Tanah Perorangan lebih dari 5 Bidang hanya Untuk Pewarisan</li>

              </ul>
              {{-- <p class="fst-italic">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                magna aliqua.
              </p> --}}
            </div>

            <div class="col-12 mt-3">
              <h5>Simulasi Biaya</h5>
            </div>
            <div class="col-12">
              <form id="form_simulasi_biaya">
              <div class="row">

                <div class="col-4 mt-2" >
                    <label for="">Penggunaan</label>
                </div>
                <div class="col-8 mt-2">
                  <select id="jenis_tanah" class="form-control">
                    <option value="1">Pertanian</option>
                    <option value="2">Non Pertanian</option>  
                  </select>
                </div>
                <div class="col-4 mt-2" >
                    <label for="">Luas Bidang Tanah</label>  
                </div>
                <div class="col-8 mt-2">
                  <input type="number" class="form-control form-control-sm" id="luas" value="120" min="1" required>
                </div>
                <div class="col-4 mt-2" >
                    <label for="">Jumlah Bidang</label>  
                </div>
                <div class="col-8 mt-2">
                  <input type="number" class="form-control form-control-sm" id="jumlah" min="1" value="2" required>
                </div>
                <div class="col-4 mt-2" ></div>
                <div class="col-8 mt-2">
                  <button type="submit" class="btn btn-success btn-sm" id="lanjutkan">Tambah Bidang</button>
                  <button type="button" class="btn btn-warning btn-sm ml-4 text-light" id="reset">Reset</button>
                </div>
    
                <div class="col-12 mt-2" id="table_simulasi" style="display:none">
                  <table class="table table-sm">
                    <thead>
                      <tr>
                        <th>Jumlah</th>
                        <th>Luas</th>
                        <th>Penggunaan</th>
                      </tr>
                    </thead>
                    <tbody id="tb_simulasi"></tbody>
                  </table>
                </div>
                <div class="col-12 mt-2" id="hasil"></div>   

              </div>
              </form>
            </div>

            

          </div>
    
        </div>
      </section><!-- End About Us Section -->
</main>

@endsection
@section('script')
<script>
  $(document).ready(function () {
    var tarif = 0;
    var tarif_pengukuran = 0;
    var tarif_pendaftaran = 0;
    var l_tanah = 0;
    $(document).on('submit', '#form_simulasi_biaya', function(event) {
                event.preventDefault();

                $('#table_simulasi').show();
                var luas = $('#luas').val();
                var jenis_tanah = $('#jenis_tanah').val();
                var jumlah = $('#jumlah').val();

                if(jenis_tanah == 1){
                  var t_pengukuran = 100;
                  var penggunaan = 'Pertanian';
                }else{
                  var t_pengukuran = 200;
                  var penggunaan = 'Non Pertanian';
                }
                var sub_pengkuran = (luas * t_pengukuran + 100000) * jumlah
                var sub_pendaftaran = 50000 * jumlah
                tarif_pengukuran += sub_pengkuran;
                tarif_pendaftaran += sub_pendaftaran;
                tarif += sub_pendaftaran + sub_pengkuran;
                l_tanah += parseInt(luas);

                var html = '<div class="alert alert-success" role="alert"><b>Luas Tanah : '+ l_tanah +' m<sup>2</sup></b> <br> <b>Estimasi Biaya : '+ tarif.toLocaleString('en-US') +'</b> <br>Teridiri dari: <br><table><tr><td>- Tarif Pengukuran</td><td>=</td><td>'+ tarif_pengukuran.toLocaleString('en-US') +'</td></tr><tr><td>- Tarif Pendaftaran</td><td>=</td><td>'+ tarif_pendaftaran.toLocaleString('en-US') +'</td></tr></table><i><u>Catatan : Biaya diatas belum termasuk biaya transportasi, akomodasi dan konsumsi yang dibebankan kepada pemohon (Pasal 21 Peraturan Pemerintah nomor 128 Tahun 2015)</u></i></div>';
                $('#hasil').html(html);

                var html_code = '<tr>';
                html_code += '<td>'+jumlah+'</td>';
                html_code += '<td>'+luas+'</td>';
                html_code += '<td>'+penggunaan+'</td>';
                html_code += '</tr>';

                $('#tb_simulasi').append(html_code);

    });

    $(document).on('click', '#reset', function() {
      tarif = 0;
      tarif_pengukuran = 0;
      tarif_pendaftaran = 0;

      $('#hasil').html('');
      $('#tb_simulasi').html('');
      $('#table_simulasi').hide();
    });



  });
</script>
@endsection
<!-- ======= About Us Section ======= -->